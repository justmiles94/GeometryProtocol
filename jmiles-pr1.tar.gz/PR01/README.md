# GeometryProtocol
Custom web protocol for networking class assigned by Dr. Gamage
